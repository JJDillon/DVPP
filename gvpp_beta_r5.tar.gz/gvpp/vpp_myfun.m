% [fun] = myfun(X)

function [fun] = vpp_myfun(X)

fun = -X(1);